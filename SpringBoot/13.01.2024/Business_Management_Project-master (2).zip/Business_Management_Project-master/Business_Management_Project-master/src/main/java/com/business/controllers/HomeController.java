package com.business.controllers;

import java.util.List;

import com.business.entities.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.business.entities.Product;
import com.business.loginCredentials.AdminLogin;
import com.business.services.ProductServices;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class HomeController 
{
	@Autowired
	private ProductServices productServices;
	@GetMapping("/home")
	public String home()
	{
		return "Home";
	}

	@GetMapping("")
	public String homee()
	{
		return "Home";
	}


	@GetMapping("/products")
	public String products( Model model)
	{ 
		List<Product> allProducts = this.productServices.getAllProducts();
		model.addAttribute("products", allProducts);
		return "Products";
	}

	@GetMapping("/location")
	public String location()
	{
		return "Locate_us";
	}

	@GetMapping("/about")
	public String about()
	{
		return "About";
	}



	@GetMapping("/register")
	public String showRegistrationPage(Model model) {
		model.addAttribute("user", new User()); // Assuming you have a User class
		return "register";
	}


	@PostMapping("/userRegister")
	public String registerUser(@ModelAttribute("user") User user){
		return "redirect:/login";
	}


	@GetMapping("/login")
	public String showLoginPage(Model model) {
		model.addAttribute("user", new User()); // Reusing the User class for login
		return "login";
	}

	@PostMapping("/userLogin")
	public String loginUser(@ModelAttribute("user") User user, Model model) {
		// TODO: Handle user login logic here
		// You may want to check credentials and set authentication
		return "redirect:/dashboard";
	}

	public static class User {
		private String userEmail;
		private String userPassword;

		// Getters and setters...
	}

}
