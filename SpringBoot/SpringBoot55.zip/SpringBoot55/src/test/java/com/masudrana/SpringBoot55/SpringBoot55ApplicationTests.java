package com.masudrana.SpringBoot55;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot55ApplicationTests {

	@Test
	void contextLoads() {
	}

}
