package com.masudrana.SpringBoot55;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoot55Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoot55Application.class, args);
	}

}
